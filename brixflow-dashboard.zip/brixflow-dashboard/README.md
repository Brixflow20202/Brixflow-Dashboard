# BrixFlow Lead Dashboard

Volledig dashboard voor het zoeken en beheren van BrixFlow leads.

## Deployen op Vercel (gratis, 5 minuten)

### Stap 1 — GitHub account aanmaken
Ga naar https://github.com en maak een gratis account aan.

### Stap 2 — Nieuw repository aanmaken
1. Klik op "New repository"
2. Naam: brixflow-dashboard
3. Klik "Create repository"

### Stap 3 — Bestanden uploaden
1. Klik "uploading an existing file"
2. Sleep de hele map (pages/, package.json) naar het uploadvenster
3. Klik "Commit changes"

### Stap 4 — Deployen op Vercel
1. Ga naar https://vercel.com en log in met je GitHub account
2. Klik "Add New Project"
3. Selecteer je brixflow-dashboard repository
4. Klik "Deploy"

Vercel detecteert automatisch dat het een Next.js project is.

### Stap 5 — API key instellen (optioneel)
Als je de API key niet elke keer wil invoeren:
1. Ga in Vercel naar je project > Settings > Environment Variables
2. Voeg toe: ANTHROPIC_API_KEY = jouw sleutel
3. Redeploy

## Lokaal draaien
```
npm install
npm run dev
```
Open http://localhost:3000

## Features
- Leads zoeken met alle filters (sectoren, vestigingen, reviewvolume, activiteit, responsstatus)
- Geleide en vrije zoekmodus
- Leads opslaan in dashboard
- Status bijhouden (Nieuw / Contacted / Gekwalificeerd / Afgewezen)
- Notities per lead
- CSV export
- API key wordt lokaal opgeslagen in browser
